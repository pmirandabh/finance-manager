# 🛡️ Guia de Backup e Restauração - Saldo+

Este guia explica como salvar seu projeto com segurança e como colocá-lo para funcionar em outro computador (ou se formatar o atual).

---

## 1. Como Fazer Backup (Salvar)

Criamos um script automático para facilitar sua vida.

### 🚀 Passo a Passo:
1.  Na pasta do projeto, dê dois cliques no arquivo:
    👉 **`backup_projeto_v2.bat`**
2.  Uma janela preta vai abrir e mostrar o progresso.
3.  Quando terminar, um arquivo **.zip** será criado na mesma pasta.
    *   Exemplo: `Backup_SaldoPlus_v1.0_2025-12-02_08-30.zip`

### 💾 Onde Guardar:
Envie esse arquivo `.zip` para um local seguro:
*   ☁️ **Google Drive / OneDrive** (Recomendado)
*   📧 **Email** (Envie para você mesmo)
*   💾 **Pendrive / HD Externo**

> **Nota:** O backup **NÃO** inclui a pasta `node_modules` (que é muito pesada e desnecessária). Ela será baixada automaticamente na restauração.

---

## 2. Como Restaurar (Voltar a Usar)

Se você perdeu os arquivos ou trocou de computador, siga estes passos para voltar a programar.

### 📋 Pré-requisitos:
Você precisa ter o **Node.js** instalado no computador.
*   Baixe e instale: [https://nodejs.org/](https://nodejs.org/) (Versão LTS)

### 🚀 Passo a Passo:
1.  **Extraia o ZIP:** Pegue o arquivo de backup e extraia em uma pasta (ex: `Meus Documentos\Projetos\SaldoPlus`).
2.  **Abra o Terminal:**
    *   Entre na pasta extraída.
    *   Clique com o botão direito em um espaço vazio e escolha **"Abrir no Terminal"** (ou PowerShell).
3.  **Instale as Dependências:**
    *   Digite o comando abaixo e aperte Enter:
        ```bash
        npm install
        ```
    *   *Aguarde o download terminar (pode levar alguns minutos).*
4.  **Inicie o Projeto:**
    *   Digite:
        ```bash
        npm run dev
        ```
    *   O projeto vai abrir no seu navegador! 🎉

---

## 3. Comandos Úteis

| Comando | O que faz |
| :--- | :--- |
| `npm run dev` | Inicia o modo de desenvolvimento (para programar) |
| `npm run build` | Cria a versão final do site (para internet) |
| `npm run build:win` | Cria o instalador para Windows (.exe) |

---

**Dúvidas?** Consulte o arquivo `README.md` para mais detalhes técnicos.
