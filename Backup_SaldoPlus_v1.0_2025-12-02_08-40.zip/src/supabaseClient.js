import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://vrxznwjinkpzlkanalds.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZyeHpud2ppbmtwemxrYW5hbGRzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQyOTYyMzEsImV4cCI6MjA3OTg3MjIzMX0.Lha4pJmYPbeah8sr1CcHELGRqmoMfrlZyspFLwMVLlA'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Admin email configuration
export const ADMIN_EMAIL = import.meta.env.VITE_ADMIN_EMAIL || 'pmirandabh@gmail.com'

