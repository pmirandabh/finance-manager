import React, { useState, useEffect, useMemo } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { supabase } from './supabaseClient';
import Login from './components/Login';
import Register from './components/Register';
import UpdatePassword from './components/UpdatePassword';
import Dashboard from './components/Dashboard';
import TransactionForm from './components/TransactionForm';
import CategoryManager from './components/CategoryManager';
import RecurringTransactions from './components/RecurringTransactions';
import MonthFilter from './components/MonthFilter';
import CategoryChart from './components/CategoryChart';
import SummaryCards from './components/SummaryCards';
import EditTransactionModal from './components/EditTransactionModal';
import DataManagement from './components/DataManagement';
import Settings from './components/Settings';
import Sidebar from './components/Sidebar';
import Analytics from './components/Analytics';
import AdminDashboard from './components/AdminDashboard';
import ProfileEditModal from './components/ProfileEditModal';
import OnboardingTour from './components/OnboardingTour';
import TransactionFilters from './components/TransactionFilters';
import { defaultCategories } from './utils/defaultCategories';
import { processRecurringTransactions } from './utils/recurring';
import { migrateTransactions } from './utils/migration';
import { StorageService } from './services/StorageService';
import { useFinancialSummary } from './hooks/useFinancialSummary';
import toast from 'react-hot-toast';
import ErrorBoundary from './components/ErrorBoundary';
import './styles/main.css';

const MainApp = () => {
  const { user, logout, profile, isAdmin } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [categories, setCategories] = useState([]);
  const [activeView, setActiveView] = useState('dashboard');
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(new Date());
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [lastAddedTransactionId, setLastAddedTransactionId] = useState(null);
  const [runTour, setRunTour] = useState(false);

  useEffect(() => {
    const hasSeenTour = localStorage.getItem('hasSeenTour');
    if (!hasSeenTour) {
      setRunTour(true);
    }
  }, []);

  const handleTourFinish = () => {
    setRunTour(false);
    localStorage.setItem('hasSeenTour', 'true');
  };

  // Filter transactions by selected month
  const filterTransactionsByMonth = (transactions, month) => {
    const monthKey = `${month.getFullYear()}-${String(month.getMonth() + 1).padStart(2, '0')}`;

    return transactions.filter(t => {
      if (t.isTemplate) return false; // Don't show templates

      // Use competenceMonth for filtering
      if (t.competenceMonth) {
        return t.competenceMonth === monthKey;
      }

      // Fallback for old data without competenceMonth
      if (t.createdDate) {
        const transactionDate = new Date(t.createdDate);
        return transactionDate.getMonth() === month.getMonth() &&
          transactionDate.getFullYear() === month.getFullYear();
      }

      return false;
    });
  };

  // Apply search and category filters
  const applyFilters = (transactions) => {
    let filtered = transactions;

    // Search by description
    if (searchTerm) {
      filtered = filtered.filter(t =>
        t.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filter by category
    if (categoryFilter) {
      filtered = filtered.filter(t => t.categoryId === categoryFilter);
    }

    return filtered;
  };

  const monthFilteredTransactions = filterTransactionsByMonth(transactions, selectedMonth);
  const filteredTransactions = applyFilters(monthFilteredTransactions);

  const handleClearFilters = () => {
    setSearchTerm('');
    setCategoryFilter('');
  };

  // Calculate financial summary once (optimization)
  // Calculate financial summary using hook
  const financialSummary = useFinancialSummary(filteredTransactions);

  // Load data when user logs in
  useEffect(() => {
    if (user) {
      loadUserData();
    }
  }, [user]);

  // Listen for online/offline events
  useEffect(() => {
    const handleOnline = () => {
      toast.success('Conexão restaurada', { icon: '🌐' });
    };

    const handleOffline = () => {
      toast.error('Sem conexão com a internet', { icon: '📡', duration: 5000 });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const loadUserData = async () => {
    setIsLoading(true);
    try {
      // Load Categories
      const loadedCategories = await StorageService.loadCategories(user.id);

      // Load Transactions
      const loadedTransactions = await StorageService.loadTransactions(user.id);

      // Process recurring transactions
      const processedTransactions = processRecurringTransactions(loadedTransactions);

      // Check if new transactions were generated
      let shouldSaveTransactions = false;
      if (processedTransactions.length !== loadedTransactions.length) {
        shouldSaveTransactions = true;
      }

      setTransactions(processedTransactions);
      setCategories(loadedCategories);

      // Save back if new recurring instances were generated
      if (shouldSaveTransactions) {
        await saveTransactions(processedTransactions);
      }

    } catch (error) {
      console.error("Failed to load user data:", error);
      toast.error('Erro ao carregar dados. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const saveTransactions = async (newTransactions) => {
    setTransactions(newTransactions);
    await StorageService.saveTransactions(user.id, newTransactions);
  };

  const handleAddTransaction = async (newTransaction) => {
    // Save the new transaction individually
    await StorageService.saveTransaction(user.id, newTransaction);

    // Update local state by adding the new transaction
    setTransactions(prev => [newTransaction, ...prev]);

    // Highlight the new transaction
    setLastAddedTransactionId(newTransaction.id);
    setTimeout(() => setLastAddedTransactionId(null), 3000); // Clear highlight after 3 seconds
  };

  const handleDeleteTransaction = (id) => {
    const updatedTransactions = transactions.filter(t => t.id !== id);
    saveTransactions(updatedTransactions);
  };

  const handlePayTransaction = (transactionId) => {
    const updatedTransactions = transactions.map(t => {
      if (t.id === transactionId) {
        return {
          ...t,
          isPaid: true,
          paymentDate: new Date().toISOString()
        };
      }
      return t;
    });
    saveTransactions(updatedTransactions);
  };

  const handleEditTransaction = (updatedTransaction) => {
    const updatedTransactions = transactions.map(t =>
      t.id === updatedTransaction.id ? updatedTransaction : t
    );
    saveTransactions(updatedTransactions);
    setEditingTransaction(null);
  };

  const handleImportData = async (data) => {
    // Validate import data structure
    if (!data || typeof data !== 'object') {
      toast.error('Erro: Arquivo inválido. O arquivo deve ser um JSON válido.');
      return;
    }

    if (data.transactions && !Array.isArray(data.transactions)) {
      toast.error('Erro: Formato de transações inválido.');
      return;
    }

    if (data.categories && !Array.isArray(data.categories)) {
      toast.error('Erro: Formato de categorias inválido.');
      return;
    }

    // Import transactions
    if (data.transactions) {
      try {
        const migratedTransactions = migrateTransactions(data.transactions);
        saveTransactions(migratedTransactions);
      } catch (error) {
        console.error('Error importing transactions:', error);
        toast.error('Erro ao importar transações. Verifique o arquivo.');
        return;
      }
    }

    // Import categories
    if (data.categories) {
      try {
        setCategories(data.categories);
        await StorageService.saveCategories(user.id, data.categories);
      } catch (error) {
        console.error('Error importing categories:', error);
        toast.error('Erro ao importar categorias. Verifique o arquivo.');
        return;
      }
    }

    toast.success('Dados importados com sucesso!');
    setActiveView('dashboard');
  };

  const handleSaveCategory = async (category) => {
    try {
      await StorageService.saveCategory(user.id, category);

      // Reload categories to get updated list
      const updatedCategories = await StorageService.loadCategories(user.id);
      setCategories(updatedCategories);

      toast.success('Categoria salva com sucesso!');
    } catch (error) {
      console.error('Error saving category:', error);
      toast.error('Erro ao salvar categoria');
    }
  };

  const handleDeleteCategory = async (categoryId) => {
    try {
      await StorageService.deleteCategory(user.id, categoryId);

      // Update local state
      const updatedCategories = categories.filter(c => c.id !== categoryId);
      setCategories(updatedCategories);

      toast.success('Categoria excluída');
    } catch (error) {
      console.error('Error deleting category:', error);
      toast.error('Erro ao excluir categoria');
    }
  };

  return (
    <div className="app-container" style={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar
        activeView={activeView}
        onNavigate={setActiveView}
        onLogout={logout}
        isAdmin={isAdmin}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      {isLoading && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0, 0, 0, 0.7)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '3rem', marginBottom: '20px' }}>⏳</div>
            <div style={{ fontSize: '1.2rem', color: 'white' }}>Carregando...</div>
          </div>
        </div>
      )}

      <div className="main-content" style={{ flex: 1, marginLeft: '230px', padding: '30px', maxWidth: '1200px' }}>
        <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
            <button
              className="hamburger-menu"
              onClick={() => setIsSidebarOpen(true)}
              style={{
                display: 'none',
                background: 'transparent',
                border: 'none',
                color: 'var(--text-primary)',
                fontSize: '1.5rem',
                cursor: 'pointer',
                padding: '5px'
              }}
            >
              ☰
            </button>
            <h2 style={{ margin: 0 }}>
              {activeView === 'dashboard' && 'Visão Geral'}
              {activeView === 'analytics' && 'Análises'}
              {activeView === 'settings' && 'Configurações'}
              {activeView === 'admin' && 'Administração'}
            </h2>
          </div>
          <div className="user-info" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span>Olá, {profile?.name || user?.email}</span>
            <button
              onClick={() => setIsProfileModalOpen(true)}
              className="btn btn-ghost"
              style={{ padding: '5px 10px', fontSize: '1.2rem' }}
              title="Editar perfil"
            >
              ⚙️
            </button>
          </div>
        </header>

        {activeView === 'settings' ? (
          <Settings
            categories={categories}
            onSaveCategory={handleSaveCategory}
            onDeleteCategory={handleDeleteCategory}
            transactions={transactions}
            onImportData={handleImportData}
          />
        ) : activeView === 'analytics' ? (
          <Analytics
            transactions={transactions}
            categories={categories}
          />
        ) : activeView === 'admin' && isAdmin ? (
          <AdminDashboard />
        ) : (
          <>
            <div id="month-filter">
              <MonthFilter currentMonth={selectedMonth} onMonthChange={setSelectedMonth} />
            </div>

            <TransactionFilters
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
              categoryFilter={categoryFilter}
              onCategoryChange={setCategoryFilter}
              categories={categories}
              onClearFilters={handleClearFilters}
            />

            <SummaryCards transactions={filteredTransactions} />

            <div className="dashboard-grid" style={{ marginTop: '24px', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
              {/* Left Column: Balance + Chart */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                {/* Balance Card */}
                <div id="balance-card" className="glass-panel card" style={{ padding: '15px' }}>
                  <h2 style={{ fontSize: '1rem', marginBottom: '10px' }}>Saldo Atual</h2>
                  <div className={`amount-display ${financialSummary.balance >= 0 ? 'income' : 'expense'}`}
                    style={{ fontSize: '2rem', marginBottom: '15px' }}>
                    R$ {financialSummary.balance.toFixed(2)}
                  </div>
                  <div style={{ display: 'flex', gap: '20px' }}>
                    <div>
                      <small style={{ fontSize: '0.75rem' }}>Receitas</small>
                      <div className="income" style={{ fontSize: '1rem' }}>
                        R$ {financialSummary.income.toFixed(2)}
                      </div>
                    </div>
                    <div>
                      <small style={{ fontSize: '0.75rem' }}>Despesas</small>
                      <div className="expense" style={{ fontSize: '1rem' }}>
                        R$ {financialSummary.expense.toFixed(2)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Category Chart */}
                <CategoryChart
                  transactions={filteredTransactions}
                  categories={categories}
                />
              </div>

              {/* Right Column: Transaction Form + Last Transactions + Pending */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <TransactionForm onAddTransaction={handleAddTransaction} categories={categories} />

                <Dashboard
                  transactions={filteredTransactions}
                  categories={categories}
                  onDeleteTransaction={handleDeleteTransaction}
                  onEditTransaction={setEditingTransaction}
                  lastAddedTransactionId={lastAddedTransactionId}
                  onNewTransaction={() => {
                    const toggle = document.getElementById('transaction-form-toggle');
                    const input = document.getElementById('transaction-description');

                    // If form is not expanded (input not visible or toggle doesn't have expanded class)
                    if (toggle && !toggle.classList.contains('expanded')) {
                      toggle.click();
                      // Wait for animation/render
                      setTimeout(() => {
                        const inputAfterExpand = document.getElementById('transaction-description');
                        if (inputAfterExpand) {
                          inputAfterExpand.focus();
                          inputAfterExpand.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        }
                      }, 100);
                    } else if (input) {
                      input.focus();
                      input.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                  }}
                />

                <RecurringTransactions
                  transactions={transactions}
                  onPayTransaction={handlePayTransaction}
                  categories={categories}
                  onDeleteTransaction={handleDeleteTransaction}
                />
              </div>
            </div>
          </>
        )}

        {editingTransaction && (
          <EditTransactionModal
            transaction={editingTransaction}
            categories={categories}
            onSave={handleEditTransaction}
            onCancel={() => setEditingTransaction(null)}
          />
        )}

        <ProfileEditModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
        />

        <OnboardingTour run={runTour} onFinish={handleTourFinish} />
      </div>
    </div>
  );
};

const App = () => {
  const { user } = useAuth();
  return user ? <MainApp /> : <div className="auth-container"><Login /></div>;
};

const AppWrapper = () => {
  const [isRegistering, setIsRegistering] = useState(false);

  return (
    <ErrorBoundary>
      <AuthProvider>
        <AuthConsumer isRegistering={isRegistering} setIsRegistering={setIsRegistering} />
      </AuthProvider>
    </ErrorBoundary>
  );
};

const AuthConsumer = ({ isRegistering, setIsRegistering }) => {
  const { user } = useAuth();
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'PASSWORD_RECOVERY') {
        setIsUpdatingPassword(true);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  if (user && !isUpdatingPassword) {
    return <MainApp />;
  }

  return (
    <div className="auth-container">
      <div className="auth-card glass-panel">
        {isUpdatingPassword ? (
          <UpdatePassword onPasswordUpdated={() => setIsUpdatingPassword(false)} />
        ) : isRegistering ? (
          <Register onSwitchToLogin={() => setIsRegistering(false)} />
        ) : (
          <Login onSwitchToRegister={() => setIsRegistering(true)} />
        )}
      </div>
    </div>
  );
};

export default AppWrapper;
