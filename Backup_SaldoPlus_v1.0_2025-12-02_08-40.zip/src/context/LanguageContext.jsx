import React, { createContext, useContext } from 'react';

const LanguageContext = createContext();

// Versão simplificada que sempre retorna português
const translations = {
    'menu.subtitle': 'Gestão Pessoal Financeira',
    'menu.dashboard': 'Dashboard',
    'menu.analytics': 'Análises',
    'menu.settings': 'Configurações',
    'menu.admin': 'Administração',
    'menu.logout': 'Sair',
    'dashboard.total': 'Total Transações',
    'dashboard.income': 'Receitas',
    'dashboard.expense': 'Despesas',
    'dashboard.balance': 'Saldo Atual',
    'dashboard.addTransaction': 'Nova Transação',
    'dashboard.noTransactions': 'Nenhuma transação neste mês',
    'dashboard.largestExpense': 'Maior Despesa',
    'dashboard.largestIncome': 'Maior Receita',
    'transaction.description': 'Descrição',
    'transaction.amount': 'Valor',
    'transaction.category': 'Categoria',
    'transaction.type': 'Tipo',
    'transaction.date': 'Data',
    'transaction.paid': 'Pago',
    'transaction.recurring': 'Recorrente',
    'transaction.notes': 'Observações',
    'transaction.save': 'Salvar',
    'transaction.cancel': 'Cancelar',
    'transaction.delete': 'Excluir',
    'transaction.edit': 'Editar',
    'transaction.income': 'Receita',
    'transaction.expense': 'Despesa',
    'transaction.selectCategory': 'Selecione uma categoria...',
    'transaction.noCategories': 'Nenhuma categoria ativa. Ative em Configurações.',
    'settings.newCategory': 'Nova Categoria',
    'settings.categoryName': 'Nome da Categoria',
    'settings.activeCategories': 'Categorias Ativas',
    'settings.inactiveCategories': 'Categorias Inativas',
    'settings.restore': 'Restaurar',
    'settings.confirmDelete': 'Tem certeza que deseja excluir esta categoria?',
    'settings.categories': 'Categorias',
    'settings.dataBackup': 'Dados e Backup',
    'settings.backupJson': 'Backup (JSON)',
    'settings.exportCsv': 'Exportar Excel (CSV)',
    'settings.importBackup': 'Importar Backup',
    'settings.confirmImport': 'Isso substituirá seus dados atuais. Deseja continuar?',
    'settings.importSuccess': 'Dados importados com sucesso!',
    'settings.invalidBackup': 'Arquivo de backup inválido.',
    'settings.importError': 'Erro ao ler o arquivo. Certifique-se de que é um JSON válido.',
    'admin.title': 'Gestão de Usuários',
    'admin.email': 'Email',
    'admin.joinDate': 'Data Cadastro',
    'admin.status': 'Status',
    'admin.actions': 'Ações',
    'admin.active': 'Ativo',
    'admin.blocked': 'Bloqueado',
    'admin.block': 'Bloquear',
    'admin.unblock': 'Desbloquear',
    'admin.role': 'Função',
    'errors.loadData': 'Erro ao carregar dados. Tente novamente.',
    'errors.generic': 'Ocorreu um erro.',
    'analytics.title': 'Análises e Relatórios',
    'analytics.subtitle': 'Visualize seus dados financeiros com gráficos e filtros avançados',
    'analytics.filters': 'Filtros',
    'analytics.startPeriod': 'Período Inicial',
    'analytics.endPeriod': 'Período Final',
    'analytics.transactionType': 'Tipo de Transação',
    'analytics.both': 'Ambos',
    'analytics.totalIncome': 'Total Receitas',
    'analytics.totalExpense': 'Total Despesas',
    'analytics.monthlyAverage': 'Média Mensal',
    'analytics.topCategory': 'Maior Categoria',
    'analytics.categoryDistribution': 'Distribuição por Categoria',
    'analytics.monthlyComparison': 'Comparativo Mensal',
    'analytics.balanceEvolution': 'Evolução do Saldo',
    'analytics.noData': 'Nenhum dado disponível para o período selecionado',
    'analytics.balance': 'Saldo',
    'analytics.noMonth': 'Sem mês',
    'analytics.noCategory': 'Sem Categoria',
    'common.loading': 'Carregando...',
    'common.welcome': 'Olá',
    'common.save': 'Salvar',
    'common.cancel': 'Cancelar',
    'common.delete': 'Excluir',
    'common.edit': 'Editar',
    'common.add': 'Adicionar',
    'common.search': 'Buscar',
    'common.filter': 'Filtrar',
    'common.export': 'Exportar',
    'common.import': 'Importar'
};

export const LanguageProvider = ({ children }) => {
    const t = (key) => {
        return translations[key] || key;
    };

    const value = {
        language: 'pt-BR',
        changeLanguage: () => { }, // Não faz nada
        t
    };

    return (
        <LanguageContext.Provider value={value}>
            {children}
        </LanguageContext.Provider>
    );
};

export const useLanguage = () => {
    const context = useContext(LanguageContext);
    if (!context) {
        throw new Error('useLanguage must be used within a LanguageProvider');
    }
    return context;
};
