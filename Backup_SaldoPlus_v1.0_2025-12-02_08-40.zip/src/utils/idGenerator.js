/**
 * ID generation utilities using nanoid for secure, unique IDs
 */
import { nanoid } from 'nanoid';

/**
 * Generates a unique ID
 * @param {number} size - Length of ID (default: 21)
 * @returns {string}
 */
export const generateId = (size = 21) => {
    return nanoid(size);
};

/**
 * Generates a unique category ID
 * @returns {string}
 */
export const generateCategoryId = () => {
    return `cat_${nanoid(16)}`;
};

/**
 * Generates a unique transaction ID
 * @returns {string}
 */
export const generateTransactionId = () => {
    return `txn_${nanoid(16)}`;
};
