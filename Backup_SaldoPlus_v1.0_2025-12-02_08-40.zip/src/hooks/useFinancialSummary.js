import { useMemo } from 'react';

export const useFinancialSummary = (transactions) => {
    return useMemo(() => {
        const paidTransactions = transactions.filter(t => t.isPaid && !t.isTemplate);

        const incomes = paidTransactions.filter(t => t.type === 'income');
        const expenses = paidTransactions.filter(t => t.type === 'expense');

        const income = incomes.reduce((sum, t) => sum + t.amount, 0);
        const expense = expenses.reduce((sum, t) => sum + t.amount, 0);

        return {
            income,
            expense,
            balance: income - expense,
            paidTransactions,
            incomes,
            expenses
        };
    }, [transactions]);
};
