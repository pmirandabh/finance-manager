                    </div >
                ))}
            </div >
        </div >
    );
};

export default RecurringManager;
