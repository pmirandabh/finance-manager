import React, { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const AdminDashboard = () => {
    const [users, setUsers] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [stats, setStats] = useState({ total: 0, active: 0, blocked: 0 });
    const { user } = useAuth();

    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = async () => {
        setIsLoading(true);
        try {
            // Fetch all profiles (requires RLS policy)
            const { data, error } = await supabase
                .from('profiles')
                .select('*')
                .order('created_at', { ascending: false });

            if (error) throw error;

            setUsers(data);

            // Calculate stats (treat null as inactive)
            const total = data.length;
            const active = data.filter(u => u.is_active === true).length;
            const blocked = data.filter(u => u.is_active === false).length;

            setStats({ total, active, blocked });
        } catch (error) {
            console.error('Error fetching users:', error);
            toast.error('Erro ao carregar usuários.');
        } finally {
            setIsLoading(false);
        }
    };

    const toggleUserStatus = async (userId, currentStatus) => {
        try {
            // Optimistic update
            setUsers(users.map(u =>
                u.id === userId ? { ...u, is_active: !currentStatus } : u
            ));

            const { error } = await supabase
                .from('profiles')
                .update({ is_active: !currentStatus })
                .eq('id', userId);

            if (error) throw error;

            // Update stats
            setStats(prev => ({
                ...prev,
                active: !currentStatus ? prev.active + 1 : prev.active - 1,
                blocked: !currentStatus ? prev.blocked - 1 : prev.blocked + 1
            }));

            toast.success(`Usuário ${!currentStatus ? 'desbloqueado' : 'bloqueado'} com sucesso`);

        } catch (error) {
            console.error('Error updating user:', error);
            toast.error('Erro ao atualizar status do usuário.');
            // Revert optimistic update
            fetchUsers();
        }
    };

    const formatDate = (dateString) => {
        if (!dateString) return 'Nunca';
        return new Date(dateString).toLocaleString('pt-BR');
    };

    return (
        <div className="admin-dashboard fade-in">
            <h1 style={{ marginBottom: '30px', display: 'flex', alignItems: 'center', gap: '10px' }}>
                <span style={{ fontSize: '2rem' }}>🛡️</span>
                Painel Administrativo
            </h1>

            {/* Stats Cards */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginBottom: '30px' }}>
                <div className="glass-panel card" style={{ textAlign: 'center', padding: '20px' }}>
                    <h3 style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '10px' }}>Total de Usuários</h3>
                    <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: 'var(--primary-color)' }}>{stats.total}</div>
                </div>
                <div className="glass-panel card" style={{ textAlign: 'center', padding: '20px' }}>
                    <h3 style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '10px' }}>Usuários Ativos</h3>
                    <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#03DAC6' }}>{stats.active}</div>
                </div>
                <div className="glass-panel card" style={{ textAlign: 'center', padding: '20px' }}>
                    <h3 style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '10px' }}>Bloqueados</h3>
                    <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#CF6679' }}>{stats.blocked}</div>
                </div>
            </div>

            {/* Users Table */}
            <div className="glass-panel" style={{ padding: '20px', overflowX: 'auto' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                    <h2 style={{ margin: 0, fontSize: '1.2rem' }}>Gerenciar Usuários</h2>
                    <button onClick={fetchUsers} className="btn btn-ghost" title="Atualizar lista">
                        🔄 Atualizar
                    </button>
                </div>

                {isLoading ? (
                    <div style={{ textAlign: 'center', padding: '40px' }}>Carregando usuários...</div>
                ) : (
                    <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '800px' }}>
                        <thead>
                            <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
                                <th style={{ textAlign: 'left', padding: '15px', color: 'var(--text-secondary)' }}>Usuário</th>
                                <th style={{ textAlign: 'left', padding: '15px', color: 'var(--text-secondary)' }}>Email</th>
                                <th style={{ textAlign: 'left', padding: '15px', color: 'var(--text-secondary)' }}>Cadastro</th>
                                <th style={{ textAlign: 'left', padding: '15px', color: 'var(--text-secondary)' }}>Último Acesso</th>
                                <th style={{ textAlign: 'center', padding: '15px', color: 'var(--text-secondary)' }}>Status</th>
                                <th style={{ textAlign: 'center', padding: '15px', color: 'var(--text-secondary)' }}>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.map(u => (
                                <tr key={u.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                                    <td style={{ padding: '15px' }}>
                                        <div style={{ fontWeight: 'bold' }}>{u.name || 'Sem nome'}</div>
                                        {u.email === user.email && <span style={{ fontSize: '0.7rem', background: 'rgba(187, 134, 252, 0.2)', color: '#BB86FC', padding: '2px 6px', borderRadius: '4px' }}>Você</span>}
                                    </td>
                                    <td style={{ padding: '15px', color: 'var(--text-secondary)' }}>{u.email}</td>
                                    <td style={{ padding: '15px', fontSize: '0.9rem' }}>{new Date(u.created_at).toLocaleDateString('pt-BR')}</td>
                                    <td style={{ padding: '15px', fontSize: '0.9rem' }}>{formatDate(u.last_login)}</td>
                                    <td style={{ padding: '15px', textAlign: 'center' }}>
                                        <span style={{
                                            padding: '4px 10px',
                                            borderRadius: '12px',
                                            fontSize: '0.8rem',
                                            background: u.is_active === true ? 'rgba(3, 218, 198, 0.1)' : 'rgba(207, 102, 121, 0.1)',
                                            color: u.is_active === true ? '#03DAC6' : '#CF6679',
                                            border: `1px solid ${u.is_active === true ? 'rgba(3, 218, 198, 0.3)' : 'rgba(207, 102, 121, 0.3)'}`
                                        }}>
                                            {u.is_active === true ? 'Ativo' : 'Bloqueado'}
                                        </span>
                                    </td>
                                    <td style={{ padding: '15px', textAlign: 'center' }}>
                                        {u.email !== user.email && (
                                            <button
                                                onClick={() => toggleUserStatus(u.id, u.is_active)}
                                                className={`btn ${u.is_active === true ? 'btn-danger' : 'btn-success'}`}
                                                style={{ padding: '6px 12px', fontSize: '0.8rem' }}
                                            >
                                                {u.is_active === true ? 'Bloquear' : 'Desbloquear'}
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
};

export default AdminDashboard;
